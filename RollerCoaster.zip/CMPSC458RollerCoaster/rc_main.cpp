#ifdef WIN32
// For VC++ you need to include this file as glut.h and gl.h refer to it
#include <windows.h>
#endif

#include <stdio.h>     // Standard Header For Most Programs
#include <stdlib.h>    // Additional standard Functions (exit() for example)
#ifdef __APPLE__

// This ONLY APPLIES to OSX
//
// Remember to add the -framework OpenGL - framework GLUT to
// to the gcc command line or include those frameworks
// using Xcode

#include <OpenGL/gl.h>     // The GL Header File
#include <OpenGL/glu.h>    // The GL Utilities (GLU) header
#include <GLUT/glut.h>   // The GL Utility Toolkit (Glut) Header
#else
#include <GL/gl.h>     // The GL Header File
#include <GL/glu.h>    // The GL Utilities (GLU) header
#include <GL/glut.h>   // The GL Utility Toolkit (Glut) Header
#endif
// Interface to libpicio, provides functions to load/save jpeg files
#include <pic.h>
#include "rc_spline.h"

/* Here we will load the spline that represents the track */
rc_Spline g_Track;

/* glut Id for the context menu */
int g_iMenuId;

#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480

/* OpenGL callback declarations 
definitions are at the end to avoid clutter */

void InitGL ( GLvoid );
void doIdle();
void display ( void );
void keyboardfunc (unsigned char key, int x, int y) ;
void menufunc(int value);



// The ubiquituous main function.
int main ( int argc, char** argv )   // Create Main Function For Bringing It All Together
{
	// get the the filename from the commandline.
	if (argc!=2)
	{
		printf("usage: %s trackfilname\n", argv[0]);
		exit(1);
	}

	/* load the track, this routine aborts if it fails */
	g_Track.loadSplineFrom(argv[1]);



	/*** The following are commands for setting up GL      ***/
	/*** No OpenGl call should be before this sequence!!!! ***/

	/* Initialize glut */
	glutInit(&argc,argv);
	/* Set up window modes */
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	/* Set window position (where it will appear when it opens) */
	glutInitWindowPosition(0,0);
	/* Set size of window */
	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	/* Create the window */
	glutCreateWindow    ( "CMPSC 458: Rollercoaster" ); // Window Title (argv[0] for current directory as title)
	/**** Call to our initialization routine****/
	InitGL ();
	/* tells glut to use a particular display function to redraw */
	glutDisplayFunc(display);
	/** allow the user to quit using the right mouse button menu **/
	/* Set menu function callback */
	g_iMenuId = glutCreateMenu(menufunc);
	/* Set identifier for menu */
	glutSetMenu(g_iMenuId);
	/* Add quit option to menu */
	glutAddMenuEntry("Quit",0);
	/* Add any other menu functions you may want here.  The format is:
	* glutAddMenuEntry(MenuEntry, EntryIndex)
	* The index is used in the menufunc to determine what option was selected
	*/
	/* Attach menu to right button clicks */
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	/* Set idle function.  You can change this to call code for your animation,
	* or place your animation code in doIdle */
	glutIdleFunc(doIdle);
	/* callback for keyboard input */
	glutKeyboardFunc(keyboardfunc);

	glutMainLoop        ( );          // Initialize The Main Loop

	return 0;
}

/* Here are all the standard OpenGL callbacks */

// initGL will perform the one time initialization by
// setting some state variables that are not going to
// be changed
void InitGL ( GLvoid )     // Create Some Everyday Functions
{

	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background

	/*if you plan to use Display lists this is a good place to
	create them  !!!YOU MUST HAVE A DISPLAY LIST FOR YOUR TRACK!!!*/
}


/* Main GL display loop.
* This function is called by GL whenever it wants to update the display.
* We will assume that the resulting image has already been created, and 
we will just paint it to the display.
*/

void display ( void )   // Create The Display Function
{

	/* replace this code with your height field implementation */
	/* you may also want to precede it with your rotation/translation/scaling */

	/* Clear buffers */
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	/* 
	!!!! This is just an example code that draws the control points on the screen
	only to be sure that this starter code actually loads the spline data
	and also shows you how to iterate through the spline points !!!

	You have to replace it by the actual code for the rollercoaster ride and use the
	control points to actually define a spline trajectory.
	*/

	/* set up the projection parameters  */
	glViewport(0,0,WINDOW_WIDTH,WINDOW_HEIGHT);			/* Reset The Current Viewport */

	glMatrixMode(GL_PROJECTION);						/* Select The Projection Matrix */
	glLoadIdentity();									/* Reset The Projection Matrix */

	/* Set up the projection matrix to be perspective */
	gluPerspective(45.0f,(GLfloat)WINDOW_WIDTH/(GLfloat)WINDOW_HEIGHT,0.1f,5000.0f);

	glMatrixMode(GL_MODELVIEW);							/* Select The Modelview Matrix */
	glLoadIdentity();
	
	/* set a reasonable viewpoint to show the control points */
	gluLookAt(0,0,20,0,0,0,0,1,0);


	glBegin(GL_POINTS);
	Vec3f currentpos(0,0,0);

	glVertex3f(currentpos.x(),currentpos.y(),currentpos.z());

	/* Here is the interesting example: iterate throught  the points */
	for(pointVectorIter ptsiter = g_Track.points().begin(); ptsiter  !=  g_Track.points().end(); ptsiter++)
	{
		/* get the next point from the iterator */
		Vec3f pt(*ptsiter);

		/* now just the uninteresting code that is no use at all for this project */
		currentpos += pt;
		glColor3f(1,1,1);
		glVertex3f(currentpos.x(),currentpos.y(),currentpos.z());

	}

	glEnd();
	/* !!! end of useless code !!! 

	/* Swap buffers, so one we just drew is displayed */
	glutSwapBuffers();
}




/* This function will be called by GL whenever a keyboard key is pressed.
* It recieves the ASCII value of the key that was pressed, along with the x
* and y coordinates of the mouse at the time the key was pressed.
*/
void keyboardfunc (unsigned char key, int x, int y) {

	/* User pressed quit key */
	if(key == 'q' || key == 'Q' || key == 27) {
		exit(0);
	}
}
/* Function that GL runs once a menu selection has been made.
* This receives the number of the menu item that was selected
*/
void menufunc(int value)
{
	switch (value)
	{
	case 0:
		exit(0);
		break;
	}
}

/* This function is called by GL whenever it is idle, usually after calling
* display.
*/
void doIdle()
{
	/* do some stuff... */

	/* make the screen update. */
	/* glutPostRedisplay(); */
}